package version

// Version is the version of the build.
const Version = "1.8.0"
